package ua.com.testing.dao;

public interface TestDao {
}
