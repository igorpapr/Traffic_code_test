package ua.com.testing.entity.question;

public enum Type {
    SINGLE,MULTI,COMPL
}
